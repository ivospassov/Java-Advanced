package animals;

public class Main {
    public static void main(String[] args) {
        Animal animal = new Dog("Woofy", "Pedigree");
        System.out.println(animal.explainSelf());
        Animal animal1 = new Cat("Tom", "Wiskas");
        System.out.println(animal1.explainSelf());
    }
}

package animals;

public class Cat extends Animal{

    public Cat(String name, String favouriteFood) {
        super(name, favouriteFood);
    }

    @Override
    protected String explainSelf() {
        return String.format("My name is %s and my favourite food is %s\nMEEOW", super.getName(), super.getFavouriteFood());
    }
}

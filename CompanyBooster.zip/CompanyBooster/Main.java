package Defining_Classes.CompanyBooster;

import Defining_Classes.OpinionPoll.Person;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        Map<String, List<Employee>> departmentMap = new HashMap<>();

        for (int i = 0; i < n; i++) {
            String[] employeeInput = scanner.nextLine().split("\\s+");
            String name = employeeInput[0];
            double salary = Double.parseDouble(employeeInput[1]);
            String position = employeeInput[2];
            String department = employeeInput[3];
            Employee employee = null;

            //Possible input options:
            //4 Parameters - name, salary, position, department
            //5 Parameters - name, salary, position, department, email
            //5 Parameters - name, salary, position, department, age
            //6 Parameters - name, salary, position, department, email, age

            if (employeeInput.length == 6) {
                String email = employeeInput[4];
                int age = Integer.parseInt(employeeInput[5]);
                employee = new Employee(name, salary, position, department, email, age);
            }


            else if (employeeInput.length == 4) {
                employee = new Employee(name, salary, position, department);
            }


            else if (employeeInput.length == 5) {

                String fifthParameter = employeeInput[4];//Is it email or age?

                if (fifthParameter.contains("@")) {
                    employee = new Employee(name, salary, position, department, fifthParameter);
                } else {
                    employee = new Employee(name, salary, position, department, Integer.parseInt(fifthParameter));
                }
            }

            //Check if Map contains Key "Department" -->
            if (!departmentMap.containsKey(department)) {
                departmentMap.put(department, new ArrayList<>());
            }
            departmentMap.get(department).add(employee);
        }

        //Which department has the highest average salary?
        String maxAverageSalaryDepartment = departmentMap.entrySet()
                .stream().max(Comparator.comparingDouble(employeeList ->
                        getAverageSalary(employeeList.getValue())))
                .get()//Entry -> List of employees
                .getKey();


        System.out.printf("Highest Average Salary: %s", maxAverageSalaryDepartment);


        List<Employee> emploeeHighestSalary = departmentMap.get(maxAverageSalaryDepartment);
        emploeeHighestSalary.sort(Comparator.comparing(e -> e.getSalary()));
        Collections.reverse(emploeeHighestSalary);


        for (Employee employee : emploeeHighestSalary) {
            System.out.println(employee.toString());
        }
    }

    public static double getAverageSalary(List<Employee> employees) {

        double sum = 0;
        for (Employee employee : employees) {
            sum += employee.getSalary();
        }

        return sum / employees.size();
    }
}

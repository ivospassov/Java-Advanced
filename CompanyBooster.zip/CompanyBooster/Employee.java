package Defining_Classes.CompanyBooster;

public class Employee {
    //Mandatory Characteristics
    private String name;
    private double salary;
    private String position;
    private String department;

    //Optional Characteristics
    private String email;
    private int age;

    //6 Parameters - name, salary, position, department, email, age
    public Employee(String name, double salary, String position, String department, String email, int age) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.email = email;
        this.age = age;
    }

    //4 Parameters - name, salary, position, department
    public Employee(String name, double salary, String position, String department) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
    }

    //5 Parameters - name, salary, position, department, email
    public Employee(String name, double salary, String position, String department, String email) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.email = email;
    }

    //5 Parameters - name, salary, position, department, age
    public Employee(String name, double salary, String position, String department, int age) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(name + " ").append(salary + " ");

        if (email != null) {
            sb.append(email + " ");
        } else {
            sb.append("n/a");
        }


        if (age != 0) {
            sb.append(age);
        } else {
            sb.append("-1");
        }

        return sb.toString();
    }
}

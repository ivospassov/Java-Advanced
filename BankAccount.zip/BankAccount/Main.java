package Defining_Classes.BankAccount;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split("\\s+");

        String command = input[0];

        Map<Integer, Bank_Account> account = new HashMap<>();

        while (!command.equals("end")) {
            String result = "";


            switch (command) {
                case "Create":
                    Bank_Account bank_account = new Bank_Account();
                    account.put(bank_account.getId(), bank_account);
                    result = String.format("Account ID%d created", bank_account.getId());
                    System.out.println(result);
                    break;

                case "Deposit":
                    int accountPosition = Integer.parseInt(input[1]);
                    double depositAmount = Double.parseDouble(input[2]);
                    if (account.containsKey(accountPosition)) {
                        Bank_Account bankAccountFromMap = account.get(accountPosition);
                        bankAccountFromMap.deposit(depositAmount);
                        account.put(accountPosition, bankAccountFromMap);
                        result = String.format("Deposited %.0f to ID%d", depositAmount, accountPosition);
                    } else {
                        result = "Account does not exist";
                    }
                    System.out.println(result);
                    break;

                case "SetInterest":
                    double newInterestRate = Double.parseDouble(input[1]);
                    Bank_Account.setInterestRate(newInterestRate);
                    break;

                case "GetInterest":
                    int accountId = Integer.parseInt(input[1]);
                    int years = Integer.parseInt(input[2]);

                    if (account.containsKey(accountId)) {
                        Bank_Account bankAccount1 = account.get(accountId);
                        double amountedInterest = bankAccount1.getInterest(years);
                        result = String.format("%.2f", amountedInterest);
                    } else {
                        result = "Account does not exist";
                    }
                    System.out.println(result);
                    break;

            }

            input = scanner.nextLine().split("\\s+");
            command = input[0];
        }
    }
}

package Defining_Classes.BankAccount;

public class Bank_Account {
    private static double interestRate = 0.02;
    private static int accountsCounter = 0;

    private int id;
    private double balance;

    public Bank_Account() {
        accountsCounter++;
        this.id = accountsCounter;
        this.balance = 0;
    }

    public static void setInterestRate(double interestRate) {
        Bank_Account.interestRate = interestRate;
    }

    public void deposit(double money) {
        this.balance += money;
    }

    public double getInterest(int years) {
        return years * interestRate * this.balance;
    }

    public int getId() {
        return id;
    }
}

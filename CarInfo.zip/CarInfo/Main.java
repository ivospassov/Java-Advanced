package Defining_Classes.CarInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        List<Car> carsList = new ArrayList<>();

        for (int i = 1; i <= n; i++) {
            String[] infoCar = scanner.nextLine().split("\\s+");
            Car car;

            if (infoCar.length == 1) {
                car = new Car(infoCar[0]);
            } else {
                car = new Car(infoCar[0], infoCar[1], Integer.parseInt(infoCar[2]));
            }
            carsList.add(car);
        }

        carsList.forEach(car -> System.out.println(car.printCar()));
    }
}
